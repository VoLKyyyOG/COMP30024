from player.greedy.player import GreedyPlayer as Player
