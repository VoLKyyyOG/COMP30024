from player.terminal.player import TerminalPlayer as Player
