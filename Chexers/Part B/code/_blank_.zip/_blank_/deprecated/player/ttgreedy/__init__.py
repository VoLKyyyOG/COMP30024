from player.ttgreedy.player import GreedyPlayer as Player
