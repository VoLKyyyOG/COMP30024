from player.fixed_slow.player import Slow as Player
