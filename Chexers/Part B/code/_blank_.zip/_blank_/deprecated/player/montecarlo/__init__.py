from player.montecarlo.player import MCPlayer as Player
