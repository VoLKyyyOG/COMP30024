from player.slow.player import Slow as Player
