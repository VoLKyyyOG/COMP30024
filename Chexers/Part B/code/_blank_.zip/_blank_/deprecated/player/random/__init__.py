from player.random.player import RandomPlayer as Player
