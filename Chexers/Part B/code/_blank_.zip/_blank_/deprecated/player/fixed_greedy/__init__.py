from player.fixed_greedy.player import GreedyPlayer as Player
